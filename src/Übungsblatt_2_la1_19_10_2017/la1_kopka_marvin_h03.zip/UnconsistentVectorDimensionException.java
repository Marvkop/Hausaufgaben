

public class UnconsistentVectorDimensionException extends RuntimeException {

    public UnconsistentVectorDimensionException ( String message ) {

        super( message );

    }

}
