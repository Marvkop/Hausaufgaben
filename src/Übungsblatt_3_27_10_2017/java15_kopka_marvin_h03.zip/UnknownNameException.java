

public class UnknownNameException extends RuntimeException {

	public UnknownNameException( String message ) {

		super( message );
	}

}